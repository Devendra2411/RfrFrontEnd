export class ErrorObject {
  type: string;
  global: any[];
  fields: Map<String, any[]>;
}
