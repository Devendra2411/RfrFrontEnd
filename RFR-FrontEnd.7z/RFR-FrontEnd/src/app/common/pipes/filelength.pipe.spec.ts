import { FilelengthPipe } from './filelength.pipe';

describe('FilelengthPipe', () => {
  it('create an instance', () => {
    const pipe = new FilelengthPipe();
    expect(pipe).toBeTruthy();
  });
});
