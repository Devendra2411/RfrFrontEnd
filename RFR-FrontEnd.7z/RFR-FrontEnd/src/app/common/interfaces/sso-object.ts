export interface SSOObject {
  sso: string;
  firstName: string;
  lastName: string;
  emailId: string;
  name: string;
}
