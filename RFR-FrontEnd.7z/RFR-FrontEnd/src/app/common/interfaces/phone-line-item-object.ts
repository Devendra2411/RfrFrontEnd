export class PhoneLineItemObject {
    meetingId: number;
    meetingLine: string;
    meetingDate: any;
    createdBy: string;
    createdDate: any;
    phoneCallMinutes: string;

    modifiedDate: any;
    modifiedBy: string;

}
