export class ActionItemObject {
    actionItemId: number;
    itemTitle: string;
    dueDate: string;
    levelValue: number;
    status: string;
    category: string;
    owner: string;
    taskType: string;
}
