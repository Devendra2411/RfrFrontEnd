export interface Breadcrumb {
  text: string;  // The text to display
  path: string;   // The associated path
}
